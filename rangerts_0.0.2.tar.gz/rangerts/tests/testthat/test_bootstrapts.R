library(rangerts)
library(survival)
context("bootstrap_ts")


test_that("Does not crash when variable named 'none'", {
  dat <- data.frame(y = rbinom(100, 1, .5),
                    x = rbinom(100, 1, .5),
                    none = rbinom(100, 1, .5))
  rf <- ranger(data = dat, dependent.variable.name = "y",
               bootstrap.ts = 'seasonal',
               block.size = 9,
               period = 5)
  expect_equal(rf$forest$independent.variable.names, c("x", "none"))
  expect_true(!is.na(rf$prediction.error))
  expect_true(all(!is.na(rf$predictions)))
})
