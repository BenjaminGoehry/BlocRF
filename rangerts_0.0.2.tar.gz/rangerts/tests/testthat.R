library(testthat)
library(rangerts)

test_check("rangerts")
