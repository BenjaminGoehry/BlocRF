#' @title Data
#' @docType data
"elec_data"
